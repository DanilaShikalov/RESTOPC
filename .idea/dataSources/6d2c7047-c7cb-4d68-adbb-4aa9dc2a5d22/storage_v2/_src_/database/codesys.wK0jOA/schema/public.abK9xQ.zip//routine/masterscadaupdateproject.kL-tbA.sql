create function masterscadaupdateproject(OUT a_projectid integer, a_name text) returns integer
    language plpgsql
as
$$
BEGIN
        SELECT ProjectID FROM MasterSCADAProjects WHERE Name = a_Name INTO a_ProjectID;
        IF (a_ProjectID is null) THEN
          BEGIN
            SELECT MAX(ProjectID) + 1 FROM MasterSCADAProjects INTO a_ProjectID;
            IF (a_ProjectID is null) THEN
              a_ProjectID := 1;
            END IF;
            INSERT INTO MasterSCADAProjects VALUES (a_ProjectID, a_Name);
          END;
        END IF;
      END;
$$;

alter function masterscadaupdateproject(out integer, text) owner to postgres;

