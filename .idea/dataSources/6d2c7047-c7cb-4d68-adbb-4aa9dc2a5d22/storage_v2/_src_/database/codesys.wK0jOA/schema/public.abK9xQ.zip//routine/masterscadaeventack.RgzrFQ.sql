create function masterscadaeventack(a_projectid integer, a_timestampsec bigint, a_recid bigint, a_objectstateid bigint, a_comment text, a_compid integer, a_actorid integer, a_acktime timestamp without time zone, a_actorcompid integer) returns integer
    language plpgsql
as
$$
DECLARE
        a_NewState         smallint;
        a_res              integer;
        a_PrevTimestampSec bigint;
      BEGIN
        SELECT NewState | 4 FROM MasterSCADAEventData
          WHERE
            ProjectID     = a_ProjectID and
            TimestampSec  = a_TimestampSec and
            RecID         = a_RecID and
            ObjectStateID = a_ObjectStateID
          INTO a_NewState;
          
        GET DIAGNOSTICS a_res = ROW_COUNT;

        UPDATE MasterSCADAEventData
          SET
            NewState    = a_NewState,
            AckTime     = a_AckTime,
            Comment     = a_Comment,
            ActorID     = a_ActorID,
            ActorCompID = a_ActorCompID
          WHERE
            ProjectID     = a_ProjectID and
            TimestampSec  = a_TimestampSec and
            RecID         = a_RecID and
            ObjectStateID = a_ObjectStateID;

        INSERT INTO MasterSCADAEventChanges VALUES (a_ProjectID, EXTRACT(EPOCH FROM a_AckTime)::bigint,
                                                    a_TimestampSec, a_RecID, a_NewState, a_CompID, 0, a_ObjectStateID);
        
        IF (a_res > 0) THEN
          BEGIN
            SELECT TimestampSec FROM MasterSCADAActualEvents
              WHERE
                ProjectID     = a_ProjectID and
                RecID         = a_RecID and
                ObjectStateID = a_ObjectStateID
                INTO a_PrevTimestampSec;
              
            IF (a_PrevTimestampSec is null) THEN
              INSERT INTO MasterSCADAActualEvents VALUES (a_ProjectID, a_RecID, a_TimestampSec, a_NewState, a_CompID, 0, a_ObjectStateID);
            ELSIF (a_PrevTimestampSec <= a_TimestampSec) THEN
              UPDATE MasterSCADAActualEvents
                SET
                  TimestampSec = a_TimestampSec,
                  NewState     = a_NewState,
                  CompID       = a_CompID
                WHERE
                  ProjectID     = a_ProjectID and
                  RecID         = a_RecID and
                  ObjectStateID = a_ObjectStateID;
            END IF;
          END;
        END IF;
        RETURN a_res;
      END
$$;

alter function masterscadaeventack(integer, bigint, bigint, bigint, text, integer, integer, timestamp, integer) owner to postgres;

