create function masterscadaeventreadallactiveevents(a_projectid integer)
    returns TABLE(timestampsec bigint, recid bigint, objectstateid bigint, sourceid integer, objectid integer, condition integer, subcondition smallint, newstate smallint, inactivetime timestamp without time zone, acktime timestamp without time zone, actorid integer, eventtype integer, quality smallint, message text, eventsourcetype smallint, ackrequired boolean, category integer, severity integer, channels integer, comment text, actorcompid integer)
    language plpgsql
as
$$
BEGIN
        RETURN QUERY SELECT MasterSCADAEventData.TimestampSec,
          MasterSCADAEventData.RecID,
          MasterSCADAEventData.ObjectStateID,
          MasterSCADAEventData.SourceID,
          MasterSCADAEventData.ObjectID,
          MasterSCADAEventData.Condition,
          MasterSCADAEventData.Subcondition,
          MasterSCADAEventData.NewState,
          MasterSCADAEventData.InactiveTime,
          MasterSCADAEventData.AckTime,
          MasterSCADAEventData.ActorID,
          MasterSCADAEventData.EventType,
          MasterSCADAEventData.Quality,
          MasterSCADAEventData.Message,
          MasterSCADAEventData.EventSourceType,
          MasterSCADAEventData.AckRequired,
          MasterSCADAEventData.Category,
          MasterSCADAEventData.Severity,
          MasterSCADAEventData.Channels,
          MasterSCADAEventData.Comment,
          MasterSCADAEventData.ActorCompID
          FROM
            MasterSCADAActualEvents, MasterSCADAEventData
          WHERE
            MasterSCADAActualEvents.ProjectID     = a_ProjectID and
            MasterSCADAActualEvents.ProjectID     = MasterSCADAEventData.ProjectID and
            MasterSCADAActualEvents.TimestampSec  = MasterSCADAEventData.TimestampSec and
            MasterSCADAActualEvents.RecID         = MasterSCADAEventData.RecID and
            MasterSCADAActualEvents.ObjectStateID = MasterSCADAEventData.ObjectStateID;
      END
$$;

alter function masterscadaeventreadallactiveevents(integer) owner to postgres;

