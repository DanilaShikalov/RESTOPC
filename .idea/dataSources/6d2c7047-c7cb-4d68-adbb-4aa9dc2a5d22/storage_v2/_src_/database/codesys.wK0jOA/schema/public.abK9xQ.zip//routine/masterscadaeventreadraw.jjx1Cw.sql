create function masterscadaeventreadraw(a_projectid integer, a_timestampsec bigint, a_recid bigint, a_objectstateid bigint, a_inverse boolean, a_celt integer)
    returns TABLE(timestampsec bigint, recid bigint, objectstateid bigint, sourceid integer, objectid integer, condition integer, subcondition smallint, newstate smallint, inactivetime timestamp without time zone, acktime timestamp without time zone, actorid integer, eventtype integer, quality smallint, message text, eventsourcetype smallint, ackrequired boolean, category integer, severity integer, channels integer, comment text, actorcompid integer)
    language plpgsql
as
$$
BEGIN
        IF (a_Celt = 0) THEN
          BEGIN
            IF (a_Inverse = false) THEN
              RETURN QUERY SELECT MasterSCADAEventData.TimestampSec,
                MasterSCADAEventData.RecID,
                MasterSCADAEventData.ObjectStateID,
                MasterSCADAEventData.SourceID,
                MasterSCADAEventData.ObjectID,
                MasterSCADAEventData.Condition,
                MasterSCADAEventData.Subcondition,
                MasterSCADAEventData.NewState,
                MasterSCADAEventData.InactiveTime,
                MasterSCADAEventData.AckTime,
                MasterSCADAEventData.ActorID,
                MasterSCADAEventData.EventType,
                MasterSCADAEventData.Quality,
                MasterSCADAEventData.Message,
                MasterSCADAEventData.EventSourceType,
                MasterSCADAEventData.AckRequired,
                MasterSCADAEventData.Category,
                MasterSCADAEventData.Severity,
                MasterSCADAEventData.Channels,
                MasterSCADAEventData.Comment,
                MasterSCADAEventData.ActorCompID
                FROM
                  MasterSCADAEventData
                WHERE
                  ProjectID = a_ProjectID and
                  MasterSCADAEventData.TimestampSec >= a_TimestampSec and
                  (MasterSCADAEventData.TimestampSec > a_TimestampSec or a_RecID = 0 or MasterSCADAEventData.RecID >= a_RecID) and
                  (a_ObjectStateID = 0 or MasterSCADAEventData.ObjectStateID = a_ObjectStateID)
                ORDER BY MasterSCADAEventData.ProjectID ASC, MasterSCADAEventData.TimestampSec ASC, MasterSCADAEventData.RecID ASC, MasterSCADAEventData.ObjectStateID ASC;
            ELSE
              RETURN QUERY SELECT MasterSCADAEventData.TimestampSec,
                MasterSCADAEventData.RecID,
                MasterSCADAEventData.ObjectStateID,
                MasterSCADAEventData.SourceID,
                MasterSCADAEventData.ObjectID,
                MasterSCADAEventData.Condition,
                MasterSCADAEventData.Subcondition,
                MasterSCADAEventData.NewState,
                MasterSCADAEventData.InactiveTime,
                MasterSCADAEventData.AckTime,
                MasterSCADAEventData.ActorID,
                MasterSCADAEventData.EventType,
                MasterSCADAEventData.Quality,
                MasterSCADAEventData.Message,
                MasterSCADAEventData.EventSourceType,
                MasterSCADAEventData.AckRequired,
                MasterSCADAEventData.Category,
                MasterSCADAEventData.Severity,
                MasterSCADAEventData.Channels,
                MasterSCADAEventData.Comment,
                MasterSCADAEventData.ActorCompID
                FROM
                  MasterSCADAEventData
                WHERE
                  ProjectID = a_ProjectID and
                  MasterSCADAEventData.TimestampSec <= a_TimestampSec and
                  (MasterSCADAEventData.TimestampSec < a_TimestampSec or a_RecID = 0 or MasterSCADAEventData.RecID <= a_RecID) and
                  (a_ObjectStateID = 0 or MasterSCADAEventData.ObjectStateID = a_ObjectStateID)
                ORDER BY MasterSCADAEventData.ProjectID DESC, MasterSCADAEventData.TimestampSec DESC, MasterSCADAEventData.RecID DESC, MasterSCADAEventData.ObjectStateID DESC;
            END IF;
          END;
        ELSE
          BEGIN
            IF (a_Inverse = false) THEN
              RETURN QUERY SELECT MasterSCADAEventData.TimestampSec,
                MasterSCADAEventData.RecID,
                MasterSCADAEventData.ObjectStateID,
                MasterSCADAEventData.SourceID,
                MasterSCADAEventData.ObjectID,
                MasterSCADAEventData.Condition,
                MasterSCADAEventData.Subcondition,
                MasterSCADAEventData.NewState,
                MasterSCADAEventData.InactiveTime,
                MasterSCADAEventData.AckTime,
                MasterSCADAEventData.ActorID,
                MasterSCADAEventData.EventType,
                MasterSCADAEventData.Quality,
                MasterSCADAEventData.Message,
                MasterSCADAEventData.EventSourceType,
                MasterSCADAEventData.AckRequired,
                MasterSCADAEventData.Category,
                MasterSCADAEventData.Severity,
                MasterSCADAEventData.Channels,
                MasterSCADAEventData.Comment,
                MasterSCADAEventData.ActorCompID
                FROM
                  MasterSCADAEventData
                WHERE
                  ProjectID = a_ProjectID and
                  MasterSCADAEventData.TimestampSec >= a_TimestampSec and
                  (MasterSCADAEventData.TimestampSec > a_TimestampSec or a_RecID = 0 or MasterSCADAEventData.RecID >= a_RecID) and
                  (a_ObjectStateID = 0 or MasterSCADAEventData.ObjectStateID = a_ObjectStateID)
                ORDER BY MasterSCADAEventData.ProjectID ASC, MasterSCADAEventData.TimestampSec ASC, MasterSCADAEventData.RecID ASC, MasterSCADAEventData.ObjectStateID ASC
                LIMIT a_Celt;
            ELSE
              RETURN QUERY SELECT MasterSCADAEventData.TimestampSec,
                MasterSCADAEventData.RecID,
                MasterSCADAEventData.ObjectStateID,
                MasterSCADAEventData.SourceID,
                MasterSCADAEventData.ObjectID,
                MasterSCADAEventData.Condition,
                MasterSCADAEventData.Subcondition,
                MasterSCADAEventData.NewState,
                MasterSCADAEventData.InactiveTime,
                MasterSCADAEventData.AckTime,
                MasterSCADAEventData.ActorID,
                MasterSCADAEventData.EventType,
                MasterSCADAEventData.Quality,
                MasterSCADAEventData.Message,
                MasterSCADAEventData.EventSourceType,
                MasterSCADAEventData.AckRequired,
                MasterSCADAEventData.Category,
                MasterSCADAEventData.Severity,
                MasterSCADAEventData.Channels,
                MasterSCADAEventData.Comment,
                MasterSCADAEventData.ActorCompID
                FROM
                  MasterSCADAEventData
                WHERE
                  ProjectID        = a_ProjectID and
                  MasterSCADAEventData.TimestampSec <= a_TimestampSec and
                  (MasterSCADAEventData.TimestampSec < a_TimestampSec or a_RecID = 0 or MasterSCADAEventData.RecID <= a_RecID) and
                  (a_ObjectStateID = 0 or MasterSCADAEventData.ObjectStateID = a_ObjectStateID)
                ORDER BY MasterSCADAEventData.ProjectID DESC, MasterSCADAEventData.TimestampSec DESC, MasterSCADAEventData.RecID DESC, MasterSCADAEventData.ObjectStateID DESC
                LIMIT a_Celt;
            END IF;
          END;
        END IF;
      END
$$;

alter function masterscadaeventreadraw(integer, bigint, bigint, bigint, boolean, integer) owner to postgres;

