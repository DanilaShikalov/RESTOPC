create function masterscadadataupdateitem(a_projectid integer, a_itemid integer, a_name text, a_vartype integer, a_intervalid integer) returns void
    language plpgsql
as
$$
BEGIN
    IF EXISTS (SELECT 1 FROM MasterSCADADataItems WHERE ProjectID = a_ProjectID and ItemID = a_ItemID) THEN
        UPDATE MasterSCADADataItems SET Name = a_Name, VarType = a_VarType, IntervalID = a_IntervalID 
			WHERE ProjectID = a_ProjectID and ItemID = a_ItemID;
    ELSE
        INSERT INTO MasterSCADADataItems VALUES (a_ProjectID, a_ItemID, a_Name, a_VarType, a_IntervalID, null, null, 0);
	END IF;
END
$$;

alter function masterscadadataupdateitem(integer, integer, text, integer, integer) owner to postgres;

