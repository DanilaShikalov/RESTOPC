create function masterscadaeventremovedatabytime(a_projectid integer, a_mintime bigint) returns integer
    language plpgsql
as
$$
DECLARE
        a_RemovedCount integer;
      BEGIN
        DELETE FROM MasterSCADAEventData WHERE
          ProjectID = a_ProjectID and
          TimestampSec < a_MinTime;
          
        GET DIAGNOSTICS a_RemovedCount = ROW_COUNT;
        RETURN a_RemovedCount;
      END
$$;

alter function masterscadaeventremovedatabytime(integer, bigint) owner to postgres;

