create function masterscadaeventremovechangesbycount(a_projectid integer, a_valuescount integer) returns integer
    language plpgsql
as
$$
DECLARE
        a_MinTime        bigint;
        a_RemovedCount   integer;
      BEGIN
        SELECT MAX(ID) FROM MasterSCADAEventChanges
          WHERE ProjectID = a_ProjectID
          LIMIT a_ValuesCount
          INTO a_MinTime;
            
        IF (a_MinTime is null) THEN
	        RETURN 0;
        END IF;
        
        DELETE FROM MasterSCADAEventChanges WHERE
          ProjectID = a_ProjectID and
          ID    <= a_MinTime;
        
        GET DIAGNOSTICS a_RemovedCount = ROW_COUNT;
        RETURN a_RemovedCount;
      END
$$;

alter function masterscadaeventremovechangesbycount(integer, integer) owner to postgres;

