create function masterscadaeventupdate(a_projectid integer, a_timestampsec bigint, a_recid bigint, a_objectstateid bigint, a_compid integer, a_sourceid integer, a_objectid integer, a_condition integer, a_subcondition smallint, a_newstate smallint, a_activetime timestamp without time zone, a_inactivetime timestamp without time zone, a_acktime timestamp without time zone, a_actorid integer, a_actorcompid integer, a_eventtype integer, a_quality smallint, a_message text, a_eventsourcetype smallint, a_ackrequired boolean, a_category integer, a_severity integer, a_channels integer, a_comment text, a_flags integer) returns void
    language plpgsql
as
$$
DECLARE
        a_OldState          smallint;
        a_OldInactiveTime   timestamp;
        a_OldAckTime        timestamp;
        a_res               integer;
        a_PrevTimestampSec bigint;
      BEGIN
        SELECT NewState, InactiveTime, AckTime FROM MasterSCADAEventData WHERE
          ProjectID     = a_ProjectID and
          TimestampSec  = a_TimestampSec and
          RecID         = a_RecID and
          ObjectStateID = a_ObjectStateID
          INTO a_OldState, a_OldInactiveTime, a_OldAckTime;
        GET DIAGNOSTICS a_res = ROW_COUNT;
        IF (a_res > 0) THEN
          BEGIN
            IF ((a_NewState & 2) = 2 and (a_OldState & 2) = 0) THEN
              RETURN;
            END IF;
            IF (a_InactiveTime < a_OldInactiveTime) THEN
              a_InactiveTime = a_OldInactiveTime;
            END IF;
            IF (a_AckTime < a_OldAckTime) THEN
              a_AckTime = a_OldAckTime;
            END IF;
            UPDATE MasterSCADAEventData
              SET
                NewState      = a_NewState,
                InactiveTime  = a_InactiveTime,
                AckTime       = a_AckTime,
                Comment       = a_Comment,
                ActorID       = a_ActorID,
                ActorCompID   = a_ActorCompID,
                AckRequired   = a_AckRequired,
                Severity      = a_Severity
              WHERE
                ProjectID     = a_ProjectID and
                TimestampSec  = a_TimestampSec and
                RecID         = a_RecID and
                ObjectStateID = a_ObjectStateID;
          END;
        ELSE
          INSERT INTO MasterSCADAEventData VALUES (a_ProjectID, a_TimestampSec, a_RecID, a_CompID, a_SourceID, a_ObjectID, a_Condition, a_Subcondition, a_NewState, a_ActiveTime, a_InactiveTime,
            a_AckTime, a_ActorID, a_EventType, a_Quality, a_Message, a_EventSourceType, a_AckRequired, a_Category, a_Severity, a_Channels, a_Comment, a_ActorCompID, a_ObjectStateID);
        END IF;

        INSERT INTO MasterSCADAEventChanges VALUES (a_ProjectID, EXTRACT(EPOCH FROM CURRENT_Timestamp AT TIME ZONE 'UTC')::bigint,
          a_TimestampSec, a_RecID, a_NewState, a_CompID, a_Flags, a_ObjectStateID);
        
        SELECT TimestampSec FROM MasterSCADAActualEvents WHERE
          ProjectID = a_ProjectID and
          RecID     = a_RecID and
          ObjectStateID = a_ObjectStateID
          INTO a_PrevTimestampSec;
          
        IF (a_PrevTimestampSec is null) THEN
          INSERT INTO MasterSCADAActualEvents VALUES (a_ProjectID, a_RecID, a_TimestampSec, a_NewState, a_CompID, a_Flags, a_ObjectStateID);
        ELSIF (a_PrevTimestampSec <= a_TimestampSec) THEN
          UPDATE MasterSCADAActualEvents SET TimestampSec = a_TimestampSec, NewState = a_NewState, CompID = a_CompID, Flags = a_Flags WHERE
            ProjectID = a_ProjectID and
            RecID     = a_RecID and
            ObjectStateID = a_ObjectStateID;
        END IF;
      END
$$;

alter function masterscadaeventupdate(integer, bigint, bigint, bigint, integer, integer, integer, integer, smallint, smallint, timestamp, timestamp, timestamp, integer, integer, integer, smallint, text, smallint, boolean, integer, integer, integer, text, integer) owner to postgres;

