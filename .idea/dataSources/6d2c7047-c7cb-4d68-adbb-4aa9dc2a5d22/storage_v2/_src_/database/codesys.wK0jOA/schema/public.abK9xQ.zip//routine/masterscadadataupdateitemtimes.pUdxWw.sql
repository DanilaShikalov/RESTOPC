create function masterscadadataupdateitemtimes(a_projectid integer, a_itemid integer, a_addedcount integer, a_firsttime bigint, a_lasttime bigint) returns void
    language plpgsql
as
$$
BEGIN
	IF (a_FirstTime is not null) THEN
		BEGIN
			UPDATE MasterSCADADataItems SET FirstTime = a_FirstTime WHERE
			ProjectID = a_ProjectID and
			ItemID    = a_ItemID and
			(FirstTime is null or FirstTime > a_FirstTime);
		END;
	END IF;
	IF (a_LastTime is not null) THEN
		BEGIN
			UPDATE MasterSCADADataItems SET LastTime = a_LastTime WHERE
			ProjectID = a_ProjectID and
			ItemID    = a_ItemID and
			(LastTime is null or LastTime < a_LastTime);
		END;
	END IF;
	IF (a_AddedCount is not null) THEN
		BEGIN
			UPDATE MasterSCADADataItems SET ValuesCount = COALESCE(ValuesCount, 0) + a_AddedCount WHERE
			ProjectID = a_ProjectID and
			ItemID    = a_ItemID;
		END;
	END IF;
END
$$;

alter function masterscadadataupdateitemtimes(integer, integer, integer, bigint, bigint) owner to postgres;

