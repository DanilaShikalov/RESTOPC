create function masterscadadataupdateparammintimeandcount(a_projectid integer, a_itemid integer, a_mintime bigint, a_removedcount integer) returns void
    language plpgsql
as
$$
BEGIN
	UPDATE MasterSCADADataItems SET ValuesCount = ValuesCount - a_RemovedCount WHERE
		ProjectID = a_ProjectID and
		ItemID    = a_ItemID;
		
	UPDATE MasterSCADADataItems SET FirstTime = a_MinTime WHERE
		ProjectID = a_ProjectID and
		ItemID    = a_ItemID and
		FirstTime < a_MinTime;
END
$$;

alter function masterscadadataupdateparammintimeandcount(integer, integer, bigint, integer) owner to postgres;

