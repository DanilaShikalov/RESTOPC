create function masterscadaeventreadnewevents(a_projectid integer, a_lastchangingid bigint)
    returns TABLE(id bigint, timestampsec bigint, recid bigint, objectstateid bigint, sourceid integer, objectid integer, condition integer, subcondition smallint, newstate smallint, inactivetime timestamp without time zone, acktime timestamp without time zone, actorid integer, eventtype integer, quality smallint, message text, eventsourcetype smallint, ackrequired boolean, category integer, severity integer, channels integer, comment text, compid integer, actorcompid integer, flags integer)
    language plpgsql
as
$$
BEGIN
        RETURN QUERY SELECT MasterSCADAEventChanges.ID,
          MasterSCADAEventData.TimestampSec,
          MasterSCADAEventData.RecID,
          MasterSCADAEventData.ObjectStateID,
          MasterSCADAEventData.SourceID,
          MasterSCADAEventData.ObjectID,
          MasterSCADAEventData.Condition,
          MasterSCADAEventData.Subcondition,
          MasterSCADAEventData.NewState,
          MasterSCADAEventData.InactiveTime,
          MasterSCADAEventData.AckTime,
          MasterSCADAEventData.ActorID,
          MasterSCADAEventData.EventType,
          MasterSCADAEventData.Quality,
          MasterSCADAEventData.Message,
          MasterSCADAEventData.EventSourceType,
          MasterSCADAEventData.AckRequired,
          MasterSCADAEventData.Category,
          MasterSCADAEventData.Severity,
          MasterSCADAEventData.Channels,
          MasterSCADAEventData.Comment,
          MasterSCADAEventChanges.CompID,
          MasterSCADAEventData.ActorCompID,
          MasterSCADAEventChanges.Flags
          FROM
            MasterSCADAEventChanges, MasterSCADAEventData
          WHERE
            MasterSCADAEventChanges.ProjectID     = a_ProjectID and
            MasterSCADAEventChanges.ProjectID     = MasterSCADAEventData.ProjectID and
            MasterSCADAEventChanges.TimestampSec  = MasterSCADAEventData.TimestampSec and
            MasterSCADAEventChanges.RecID         = MasterSCADAEventData.RecID and
            MasterSCADAEventChanges.ObjectStateID = MasterSCADAEventData.ObjectStateID and
            MasterSCADAEventChanges.ID           >= a_LastChangingID
          ORDER BY MasterSCADAEventChanges.ProjectID ASC, MasterSCADAEventChanges.ID ASC;
      END
$$;

alter function masterscadaeventreadnewevents(integer, bigint) owner to postgres;

