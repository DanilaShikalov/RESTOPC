create function masterscadadataupdateitemstatistics(a_projectid integer, a_itemid integer, OUT a_updatedcount bigint) returns bigint
    language plpgsql
as
$$
BEGIN
	SELECT COUNT(*) FROM MasterSCADADataRaw WHERE
		ProjectID = a_ProjectID and
		Layer IN (1, 2, 3, 4, 5, 6, 7, 8, 9, 10) and
		ItemID = a_ItemID
		INTO a_UpdatedCount;
    UPDATE MasterSCADADataItems SET ValuesCount = a_UpdatedCount WHERE
		ProjectID = a_ProjectID and
		ItemID    = a_ItemID;
END
$$;

alter function masterscadadataupdateitemstatistics(integer, integer, out bigint) owner to postgres;

