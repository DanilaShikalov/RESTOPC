create function masterscadaeventreadrawbylasttime(a_projectid integer, a_timestamp timestamp without time zone, a_recid bigint, a_objectstateid bigint, a_inverse boolean, a_celt integer)
    returns TABLE(projectid integer, timestampsec bigint, recid bigint, objectstateid bigint, compid integer, sourceid integer, objectid integer, condition integer, subcondition smallint, newstate smallint, activetime timestamp without time zone, inactivetime timestamp without time zone, acktime timestamp without time zone, actorid integer, eventtype integer, quality smallint, message text, eventsourcetype smallint, ackrequired boolean, category integer, severity integer, channels integer, comment text, actorcompid integer)
    language plpgsql
as
$$
BEGIN
        IF (a_Celt = 0) THEN
          BEGIN
            IF (a_Inverse = false) THEN
              RETURN QUERY SELECT * FROM(
                SELECT ActiveTime AS LastChangingTime, * FROM MasterSCADAEventData
                  WHERE
                    ProjectID   = a_ProjectID and
                    ActiveTime >= a_Timestamp and
                    (a_RecID = 0 or RecID <= a_RecID) and
                    (a_ObjectStateID = 0 or ObjectStateID = a_ObjectStateID)
                UNION ALL
                SELECT InactiveTime AS LastChangingTime, * FROM MasterSCADAEventData
                  WHERE
                    ProjectID     = a_ProjectID and
                    InactiveTime >= a_Timestamp and
                    (a_RecID = 0 or RecID <= a_RecID) and
                    (a_ObjectStateID = 0 or ObjectStateID = a_ObjectStateID)
			          UNION ALL
                SELECT AckTime AS LastChangingTime, * FROM MasterSCADAEventData
                  WHERE
                    ProjectID = a_ProjectID and
                    AckTime  >= a_Timestamp and
                    (a_RecID = 0 or RecID <= a_RecID) and
                    (a_ObjectStateID = 0 or ObjectStateID = a_ObjectStateID))
              AS SubQuery
              ORDER BY ProjectID ASC, LastChangingTime ASC, RecID ASC, ObjectStateID ASC;
            ELSE
              RETURN QUERY SELECT * FROM(
                SELECT ActiveTime AS LastChangingTime, * FROM MasterSCADAEventData
                  WHERE
                    ProjectID      = a_ProjectID and
                    ActiveTime <= a_Timestamp and
                    (a_RecID = 0 or RecID <= a_RecID) and
                    (a_ObjectStateID = 0 or ObjectStateID = a_ObjectStateID)
			          UNION ALL
			          SELECT InactiveTime AS LastChangingTime, * FROM MasterSCADAEventData
                  WHERE
                    ProjectID        = a_ProjectID and
                    InactiveTime <= a_Timestamp and
                    (a_RecID = 0 or RecID <= a_RecID) and
                    (a_ObjectStateID = 0 or ObjectStateID = a_ObjectStateID)
			          UNION ALL
                SELECT AckTime AS LastChangingTime, * FROM MasterSCADAEventData
                  WHERE
                    ProjectID   = a_ProjectID and
                    AckTime <= a_Timestamp and
                    (a_RecID = 0 or RecID <= a_RecID) and
                    (a_ObjectStateID = 0 or ObjectStateID = a_ObjectStateID))
              AS SubQuery
              ORDER BY ProjectID DESC, LastChangingTime DESC, RecID DESC, ObjectStateID DESC;
            END IF;
          END;
        ELSE
          BEGIN
            IF (a_Inverse = false) THEN
              RETURN QUERY SELECT * FROM(
                (SELECT ActiveTime AS LastChangingTime, * FROM MasterSCADAEventData
                  WHERE
                    ProjectID   = a_ProjectID and
                    ActiveTime >= a_Timestamp and
                    (a_RecID = 0 or RecID <= a_RecID) and
                    (a_ObjectStateID = 0 or ObjectStateID = a_ObjectStateID)
                  LIMIT a_Celt)
			          UNION ALL
			          (SELECT InactiveTime AS LastChangingTime, * FROM MasterSCADAEventData
                  WHERE
                    ProjectID     = a_ProjectID and
                    InactiveTime >= a_Timestamp and
                    (a_RecID = 0 or RecID <= a_RecID) and
                    (a_ObjectStateID = 0 or ObjectStateID = a_ObjectStateID)
                  LIMIT a_Celt)
                UNION ALL
                (SELECT AckTime AS LastChangingTime, * FROM MasterSCADAEventData
                  WHERE
                    ProjectID = a_ProjectID and
                    AckTime  >= a_Timestamp and
                    (a_RecID = 0 or RecID <= a_RecID) and
                    (a_ObjectStateID = 0 or ObjectStateID = a_ObjectStateID)
                  LIMIT a_Celt))
              AS SubQuery
              ORDER BY ProjectID ASC, LastChangingTime ASC, RecID ASC, ObjectStateID ASC
              LIMIT a_Celt;
            ELSE
              RETURN QUERY SELECT * FROM(
                (SELECT ActiveTime AS LastChangingTime, * FROM MasterSCADAEventData
                  WHERE
                    ProjectID      = a_ProjectID and
                    ActiveTime <= a_Timestamp and
                    (a_RecID = 0 or RecID <= a_RecID) and
                    (a_ObjectStateID = 0 or ObjectStateID = a_ObjectStateID)
                  LIMIT a_Celt)
			          UNION ALL
			          (SELECT InactiveTime AS LastChangingTime, * FROM MasterSCADAEventData
                  WHERE
                    ProjectID        = a_ProjectID and
                    InactiveTime <= a_Timestamp and
                    (a_RecID = 0 or RecID <= a_RecID) and
                    (a_ObjectStateID = 0 or ObjectStateID = a_ObjectStateID)
                  LIMIT a_Celt)
			          UNION ALL
			          (SELECT AckTime AS LastChangingTime, * FROM MasterSCADAEventData
                  WHERE
                    ProjectID   = a_ProjectID and
                    AckTime <= a_Timestamp and
                    (a_RecID = 0 or RecID <= a_RecID) and
                    (a_ObjectStateID = 0 or ObjectStateID = a_ObjectStateID)
                  LIMIT a_Celt))
              AS SubQuery
              ORDER BY ProjectID DESC, LastChangingTime DESC, RecID DESC, ObjectStateID DESC
              LIMIT a_Celt;
            END IF;
          END;
        END IF;
      END
$$;

alter function masterscadaeventreadrawbylasttime(integer, timestamp, bigint, bigint, boolean, integer) owner to postgres;

