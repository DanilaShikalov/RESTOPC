create function masterscadaeventremovedatabycount(a_projectid integer, a_valuescount integer) returns integer
    language plpgsql
as
$$
DECLARE
        a_MinTime bigint;
        a_RemovedCount integer;
      BEGIN
        SELECT MAX(TimestampSec) FROM MasterSCADAEventData
          WHERE ProjectID = a_ProjectID
          LIMIT a_ValuesCount
          INTO a_MinTime;

        IF (a_MinTime is null) THEN
	        RETURN 0;
        END IF;
        
        DELETE FROM MasterSCADAEventData WHERE
          ProjectID        = a_ProjectID and
          TimestampSec <= a_MinTime;
          
        GET DIAGNOSTICS a_RemovedCount = ROW_COUNT;
        RETURN a_RemovedCount;
      END
$$;

alter function masterscadaeventremovedatabycount(integer, integer) owner to postgres;

